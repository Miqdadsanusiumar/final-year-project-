import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ResearchDisclaimerModal } from './components/ResearchDisclaimerModal';
import { Dashboard } from './pages/Dashboard';
import { ScanAnalysis } from './pages/ScanAnalysis';
import { AnalysisHistory } from './pages/AnalysisHistory';
import { ModelReview } from './pages/ModelReview';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'analyze' | 'history' | 'model'>('dashboard');
  const [selectedCaseId, setSelectedCaseId] = useState<string | undefined>(undefined);
  const [showDisclaimer, setShowDisclaimer] = useState<boolean>(false);
  const [disclaimerAccepted, setDisclaimerAccepted] = useState<boolean>(false);

  useEffect(() => {
    const accepted = localStorage.getItem('lungnet_disclaimer_accepted');
    if (accepted === 'true') {
      setDisclaimerAccepted(true);
    }
  }, []);

  const handleTabChange = (tab: 'dashboard' | 'analyze' | 'history' | 'model', caseId?: string) => {
    if (tab === 'analyze' && !disclaimerAccepted) {
      setShowDisclaimer(true);
    }
    setSelectedCaseId(caseId);
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAcceptDisclaimer = () => {
    localStorage.setItem('lungnet_disclaimer_accepted', 'true');
    setDisclaimerAccepted(true);
    setShowDisclaimer(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F7FA] text-slate-900">
      {/* Global Header with 3-zone contract and persistent research bar */}
      <Header
        currentTab={currentTab}
        onTabChange={(tab) => handleTabChange(tab)}
      />

      {/* Main Page Stage */}
      <main className="flex-1 pb-16">
        {currentTab === 'dashboard' && (
          <Dashboard onNavigate={handleTabChange} />
        )}

        {currentTab === 'analyze' && (
          <ScanAnalysis
            disclaimerAccepted={disclaimerAccepted}
            onDisclaimerRequest={() => setShowDisclaimer(true)}
            onAnalysisSuccess={() => {}}
          />
        )}

        {currentTab === 'history' && (
          <AnalysisHistory
            initialSelectedId={selectedCaseId}
            onClearInitialId={() => setSelectedCaseId(undefined)}
          />
        )}

        {currentTab === 'model' && (
          <ModelReview />
        )}
      </main>

      {/* Quiet Academic Research Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">LungNet Research Platform</span>
            <span>·</span>
            <span>Undergraduate Biomedical Engineering Study</span>
          </div>

          <div className="text-center sm:text-right text-slate-500">
            <span>Protocol: Zero fabricated metrics · Verified patient-disjoint splits</span>
            <span className="mx-2">·</span>
            <span className="font-mono text-[11px]">Build v0.3.0</span>
          </div>
        </div>
      </footer>

      {/* One-time Disclaimer Modal */}
      <ResearchDisclaimerModal
        isOpen={showDisclaimer}
        onAccept={handleAcceptDisclaimer}
      />
    </div>
  );
}
