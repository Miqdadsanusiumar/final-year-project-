import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileImage,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Loader2,
  Play,
  RotateCcw,
  Sparkles,
  ClipboardCheck,
  FileText
} from 'lucide-react';
import { AnalysisCase, ClassScores, LungClass } from '../types';
import { CTViewer } from '../components/CTViewer';
import { ScoreBar } from '../components/ScoreBar';
import { SyntheticBadge } from '../components/SyntheticBadge';
import { SAMPLE_CT_SLICES } from '../utils/sampleImages';

interface ScanAnalysisProps {
  onDisclaimerRequest: () => void;
  disclaimerAccepted: boolean;
  onAnalysisSuccess: () => void;
}

export const ScanAnalysis: React.FC<ScanAnalysisProps> = ({
  onDisclaimerRequest,
  disclaimerAccepted,
  onAnalysisSuccess
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [filename, setFilename] = useState<string>('');
  const [isDemoMode, setIsDemoMode] = useState<boolean>(false);
  const [demoClass, setDemoClass] = useState<LungClass>('Benign');

  const [loading, setLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisCase | null>(null);

  // Review status states
  const [reviewStatus, setReviewStatus] = useState<'unreviewed' | 'reviewed' | 'flagged'>('unreviewed');
  const [reviewNotes, setReviewNotes] = useState<string>('');
  const [reviewSaved, setReviewSaved] = useState<boolean>(false);
  const [savingReview, setSavingReview] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    setError(null);
    setResult(null);
    setReviewSaved(false);

    // Validate size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError("File exceeds maximum allowable size of 10MB. Please choose a smaller slice.");
      return;
    }

    // Validate type (PNG or JPEG)
    if (!['image/png', 'image/jpeg'].includes(file.type)) {
      setError("Invalid file format. Only authentic PNG and JPEG images are supported.");
      return;
    }

    setSelectedFile(file);
    setFilename(file.name);
    setIsDemoMode(false);

    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleRunDemo = (type: LungClass) => {
    if (!disclaimerAccepted) {
      onDisclaimerRequest();
      return;
    }

    setError(null);
    setResult(null);
    setSelectedFile(null);
    setIsDemoMode(true);
    setDemoClass(type);
    setReviewSaved(false);

    let sample: { id: string; filename: string; title: string; description: string; category: LungClass; svgDataUri: string } = SAMPLE_CT_SLICES.benign;
    if (type === 'Malignant') sample = SAMPLE_CT_SLICES.malignant;
    if (type === 'Normal') sample = SAMPLE_CT_SLICES.normal;

    setFilename(sample.filename);
    setPreviewUrl(sample.id);

    // Trigger analysis
    executeAnalysis(null, true, type);
  };

  const executeAnalysis = async (fileToAnalyze: File | null, forceMock: boolean = false, forceClass?: string) => {
    if (!disclaimerAccepted) {
      onDisclaimerRequest();
      return;
    }

    setLoading(true);
    setError(null);

    try {
      setLoadingStep("Validating image binary & magic numbers...");
      await new Promise(r => setTimeout(r, 120));

      setLoadingStep("Standardizing axial slice to 224×224 RGB...");
      await new Promise(r => setTimeout(r, 150));

      setLoadingStep("Applying ImageNet channel-wise normalization...");
      await new Promise(r => setTimeout(r, 140));

      setLoadingStep("Executing CNN feature projection & 3-class softmax...");

      const formData = new FormData();
      if (fileToAnalyze) {
        formData.append('file', fileToAnalyze);
      }
      if (forceMock || isDemoMode) {
        formData.append('force_mock', 'true');
      }
      if (forceClass) {
        formData.append('force_class', forceClass);
      }

      const response = await fetch('/api/analyze', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || errorData.error || `Analysis request failed with status ${response.status}`);
      }

      const data: AnalysisCase = await response.json();
      setResult(data);
      setReviewStatus(data.review_status);
      setReviewNotes(data.review_notes || '');
      onAnalysisSuccess();
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Service encountered an error while processing the scan.');
    } finally {
      setLoading(false);
      setLoadingStep('');
    }
  };

  const handleSaveReview = async () => {
    if (!result) return;
    setSavingReview(true);
    try {
      const res = await fetch(`/api/cases/${result.id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          review_status: reviewStatus,
          review_notes: reviewNotes
        })
      });

      if (!res.ok) throw new Error('Failed to update human review status');
      setReviewSaved(true);
      setTimeout(() => setReviewSaved(false), 3000);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed saving review status.');
    } finally {
      setSavingReview(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Title & Research Invariant Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#102E36]">
            Pulmonary CT Scan Analysis Suite
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Axial thoracic CT classification: Benign vs. Malignant vs. Normal
          </p>
        </div>

        {/* Small persistent research invariant */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-amber-50 border border-amber-300 rounded-lg text-amber-900 text-xs font-semibold">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
          <span>Research use only — not for diagnosis</span>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-lg text-rose-900 text-sm flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-semibold">Analysis Failed</h4>
            <p className="text-xs text-rose-700 mt-0.5">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="text-xs font-semibold text-rose-700 hover:text-rose-900 underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Analysis Workspace: Two Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Upload / Demo / Preview Stage (7 Cols) */}
        <div className="lg:col-span-7 space-y-5">
          {!previewUrl ? (
            /* Upload Dropzone */
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              className="border-2 border-dashed border-slate-300 hover:border-[#126B67] bg-white rounded-xl p-10 text-center transition-all shadow-xs flex flex-col items-center justify-center min-h-[380px]"
            >
              <div className="w-16 h-16 rounded-full bg-[#126B67]/10 flex items-center justify-center text-[#126B67] mb-4">
                <UploadCloud className="w-8 h-8" />
              </div>

              <h2 className="text-base font-bold text-slate-900">
                Select or drop an axial pulmonary CT scan slice
              </h2>
              <p className="mt-1 text-xs text-slate-500 max-w-md">
                Standard thoracic windowing recommended. Max file size: 10MB. Accepted formats: PNG, JPEG.
              </p>

              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      handleFileSelect(e.target.files[0]);
                    }
                  }}
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-[#126B67] rounded-lg hover:bg-[#0D524F] transition-colors shadow-sm focus:ring-2 focus:ring-[#126B67]"
                >
                  Browse Files
                </button>
              </div>

              {/* Demo Cases Divider */}
              <div className="mt-8 pt-6 border-t border-slate-200 w-full max-w-md">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-3">
                  Or load research test phantoms:
                </span>
                <div className="flex flex-wrap justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleRunDemo('Benign')}
                    className="px-3 py-1.5 text-xs font-medium text-teal-800 bg-teal-50 hover:bg-teal-100 border border-teal-200 rounded-md transition-colors"
                  >
                    Demo 1: Benign Nodule
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRunDemo('Malignant')}
                    className="px-3 py-1.5 text-xs font-medium text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-md transition-colors"
                  >
                    Demo 2: Malignant Mass
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRunDemo('Normal')}
                    className="px-3 py-1.5 text-xs font-medium text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-md transition-colors"
                  >
                    Demo 3: Normal Parenchyma
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Active Image Preview with CTViewer */
            <div className="space-y-4">
              <CTViewer
                imageUrl={previewUrl}
                filename={filename}
                onReplace={() => {
                  setPreviewUrl(null);
                  setSelectedFile(null);
                  setResult(null);
                  setError(null);
                }}
              />

              {/* Action Bar Under Preview */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 shadow-xs">
                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <FileImage className="w-4 h-4 text-slate-400" />
                  <span className="font-mono">{filename}</span>
                  {selectedFile && (
                    <span className="text-slate-400">
                      ({(selectedFile.size / 1024).toFixed(1)} KB)
                    </span>
                  )}
                  {isDemoMode && (
                    <span className="text-[10px] font-mono text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded">
                      Demo Phantom
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => {
                      setPreviewUrl(null);
                      setSelectedFile(null);
                      setResult(null);
                    }}
                    className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Clear
                  </button>

                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => executeAnalysis(selectedFile, isDemoMode, isDemoMode ? demoClass : undefined)}
                    className="inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-[#126B67] hover:bg-[#0D524F] disabled:opacity-50 rounded-lg transition-colors shadow-sm focus:ring-2 focus:ring-[#126B67]"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Analyzing...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" />
                        <span>Run Model Inference</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Quick Demo Selector Tabs if an image is already loaded */}
          {previewUrl && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium">Switch sample phantom:</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleRunDemo('Benign')}
                  className="px-2 py-1 text-[11px] font-medium text-teal-800 bg-white border border-slate-200 rounded hover:bg-teal-50"
                >
                  Benign
                </button>
                <button
                  onClick={() => handleRunDemo('Malignant')}
                  className="px-2 py-1 text-[11px] font-medium text-rose-800 bg-white border border-slate-200 rounded hover:bg-rose-50"
                >
                  Malignant
                </button>
                <button
                  onClick={() => handleRunDemo('Normal')}
                  className="px-2 py-1 text-[11px] font-medium text-blue-800 bg-white border border-slate-200 rounded hover:bg-blue-50"
                >
                  Normal
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Inference Results & Scores Stage (5 Cols) */}
        <div className="lg:col-span-5 space-y-5">
          {loading ? (
            /* Loading State with Progress Steps */
            <div className="bg-white rounded-xl border border-slate-200 p-8 shadow-xs text-center flex flex-col items-center justify-center min-h-[420px]">
              <div className="w-14 h-14 rounded-full bg-[#126B67]/10 flex items-center justify-center text-[#126B67] mb-4">
                <Loader2 className="w-7 h-7 animate-spin" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Inference In Progress
              </h3>
              <p className="mt-2 text-xs font-mono text-[#126B67] bg-[#126B67]/10 px-3 py-1.5 rounded-md max-w-sm">
                {loadingStep}
              </p>
              <p className="mt-4 text-[11px] text-slate-400 max-w-xs leading-relaxed">
                Applying spatial resize (224×224), channel standardization, and evaluating convolutional activation maps.
              </p>
            </div>
          ) : result ? (
            /* Results Panel */
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
              {/* Header Status & Synthetic Badge */}
              <div className="border-b border-slate-100 pb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-semibold text-slate-400 uppercase tracking-wider">
                    Analysis Case #{result.id}
                  </span>
                  <SyntheticBadge isSynthetic={result.is_synthetic} size="md" />
                </div>

                <div className="mt-2 flex items-baseline justify-between">
                  <div>
                    <span className="text-xs text-slate-500 block">Predicted Classification:</span>
                    <span
                      className={`text-2xl font-bold tracking-tight ${
                        result.predicted_class === 'Benign'
                          ? 'text-teal-700'
                          : result.predicted_class === 'Malignant'
                          ? 'text-rose-700'
                          : 'text-blue-700'
                      }`}
                    >
                      {result.predicted_class}
                    </span>
                  </div>

                  <span className="text-xs font-mono text-slate-500 tabular-nums">
                    Latency: {result.processing_time_ms}ms
                  </span>
                </div>
              </div>

              {/* Three-Class Probability Bars */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  <span>Class Output Head (Softmax)</span>
                  <span className="font-mono text-[10px]">Sum: 1.000</span>
                </div>

                <ScoreBar
                  label="Benign"
                  score={result.scores.benign}
                  isSynthetic={result.is_synthetic}
                  isPrimary={result.predicted_class === 'Benign'}
                  description="Non-malignant solitary lesion, granuloma, or hamartoma."
                />

                <ScoreBar
                  label="Malignant"
                  score={result.scores.malignant}
                  isSynthetic={result.is_synthetic}
                  isPrimary={result.predicted_class === 'Malignant'}
                  description="Malignant pulmonary neoplasm (e.g. adenocarcinoma or squamous)."
                />

                <ScoreBar
                  label="Normal"
                  score={result.scores.normal}
                  isSynthetic={result.is_synthetic}
                  isPrimary={result.predicted_class === 'Normal'}
                  description="Unremarkable lung parenchyma without focal mass."
                />
              </div>

              {/* Research Non-Calibration Warning */}
              <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-lg text-amber-900 text-xs leading-relaxed">
                <p className="font-semibold text-amber-950 flex items-center gap-1 mb-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                  Interpretation Caveat:
                </p>
                Scores represent raw multi-class softmax activations. They are <strong>uncalibrated</strong> and do not equate to clinical cancer risk. Human radiologist verification required.
              </div>

              {/* Human Review Section */}
              <div className="pt-4 border-t border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <ClipboardCheck className="w-4 h-4 text-[#126B67]" />
                    Human Review Protocol
                  </label>
                  {reviewSaved && (
                    <span className="text-xs text-emerald-700 font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Review Saved
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setReviewStatus('reviewed')}
                    className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-md border transition-colors ${
                      reviewStatus === 'reviewed'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Confirm / Reviewed
                  </button>

                  <button
                    type="button"
                    onClick={() => setReviewStatus('flagged')}
                    className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-md border transition-colors ${
                      reviewStatus === 'flagged'
                        ? 'bg-rose-50 text-rose-800 border-rose-300'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Flag for Secondary
                  </button>
                </div>

                <textarea
                  rows={2}
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Record radiologic observations, slice level, or nodule characteristics..."
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-200 focus:ring-1 focus:ring-[#126B67] focus:border-[#126B67]"
                />

                <button
                  type="button"
                  disabled={savingReview}
                  onClick={handleSaveReview}
                  className="w-full py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
                >
                  {savingReview ? "Saving audit record..." : "Save Review to Database"}
                </button>
              </div>
            </div>
          ) : (
            /* Empty State: Instructions */
            <div className="bg-white rounded-xl border border-slate-200 p-8 shadow-xs text-center flex flex-col items-center justify-center min-h-[420px]">
              <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-3">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-semibold text-slate-900">
                Awaiting Scan Input
              </h3>
              <p className="mt-1 text-xs text-slate-500 max-w-xs leading-relaxed">
                Upload a DICOM-derived PNG or JPEG axial slice on the left, or run a demonstration phantom to review candidate class probabilities.
              </p>

              <div className="mt-6 text-left w-full space-y-2 text-xs text-slate-600 bg-slate-50 p-4 rounded-lg border border-slate-200">
                <span className="font-semibold block text-slate-700">Protocol Checklist:</span>
                <p>1. Only valid PNG and JPEG headers accepted.</p>
                <p>2. Preprocessing pipeline crops/scales to 224×224 RGB.</p>
                <p>3. Without calibrated weights at <code className="text-[#126B67]">MODEL_PATH</code>, all scores output as <span className="font-mono text-amber-700 font-semibold">[SYNTHETIC]</span>.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
