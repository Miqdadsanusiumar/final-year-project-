import React, { useState } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Eye, RefreshCw } from 'lucide-react';
import { resolveImagePreview } from '../utils/sampleImages';

interface CTViewerProps {
  imageUrl: string;
  filename: string;
  onReplace?: () => void;
  className?: string;
}

export const CTViewer: React.FC<CTViewerProps> = ({
  imageUrl,
  filename,
  onReplace,
  className = ''
}) => {
  const [scale, setScale] = useState<number>(1);
  const [isInverted, setIsInverted] = useState<boolean>(false);

  const handleZoomIn = () => setScale(prev => Math.min(prev + 0.25, 3));
  const handleZoomOut = () => setScale(prev => Math.max(prev - 0.25, 0.5));
  const handleReset = () => {
    setScale(1);
    setIsInverted(false);
  };

  const resolvedSrc = resolveImagePreview(imageUrl);

  return (
    <div className={`flex flex-col bg-[#0B1317] rounded-xl overflow-hidden border border-slate-700/60 shadow-inner ${className}`}>
      {/* Viewer Toolbar */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-[#141E24] border-b border-slate-800 text-xs text-slate-300">
        <div className="flex items-center gap-2 truncate pr-2">
          <span className="font-mono text-slate-400 text-[11px] truncate max-w-[200px]" title={filename}>
            {filename}
          </span>
          <span className="text-[10px] uppercase font-mono text-slate-500 bg-slate-800/80 px-1.5 py-0.5 rounded">
            Axial CT
          </span>
        </div>

        {/* Viewport Controls: Zoom / Fit / Invert / Replace */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={handleZoomOut}
            className="p-1 rounded hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Zoom Out (-25%)"
            aria-label="Zoom out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono text-[11px] text-slate-400 w-10 text-center select-none tabular-nums">
            {Math.round(scale * 100)}%
          </span>
          <button
            type="button"
            onClick={handleZoomIn}
            className="p-1 rounded hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Zoom In (+25%)"
            aria-label="Zoom in"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>

          <div className="w-px h-3.5 bg-slate-700 mx-1" />

          <button
            type="button"
            onClick={handleReset}
            className="p-1 rounded hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Reset Zoom & Transform"
            aria-label="Reset zoom"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setIsInverted(!isInverted)}
            className={`p-1 rounded transition-colors ${
              isInverted ? 'bg-teal-900/60 text-teal-300' : 'hover:bg-slate-700 text-slate-300 hover:text-white'
            }`}
            title="Invert Hounsfield / Grayscale Window"
            aria-label="Invert grayscale contrast"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>

          {onReplace && (
            <>
              <div className="w-px h-3.5 bg-slate-700 mx-1" />
              <button
                type="button"
                onClick={onReplace}
                className="flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                title="Replace with another scan"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Replace</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Viewport Stage */}
      <div className="relative h-80 sm:h-96 w-full flex items-center justify-center overflow-hidden bg-[#070C0E] select-none">
        <div
          className="transition-transform duration-150 ease-out origin-center flex items-center justify-center"
          style={{
            transform: `scale(${scale})`,
            filter: isInverted ? 'invert(1) hue-rotate(180deg)' : 'none'
          }}
        >
          <img
            src={resolvedSrc}
            alt={`Computed tomography scan slice: ${filename}`}
            className="max-h-72 sm:max-h-88 max-w-full object-contain rounded pointer-events-none"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Viewport orientation markers (Axial view: Anterior / Posterior / Left / Right) */}
        <div className="absolute top-2 text-[10px] font-mono font-semibold text-slate-500 pointer-events-none">A</div>
        <div className="absolute bottom-2 text-[10px] font-mono font-semibold text-slate-500 pointer-events-none">P</div>
        <div className="absolute left-2 text-[10px] font-mono font-semibold text-slate-500 pointer-events-none">R</div>
        <div className="absolute right-2 text-[10px] font-mono font-semibold text-slate-500 pointer-events-none">L</div>

        {/* Quiet footer watermark */}
        <div className="absolute bottom-2 right-4 text-[9px] font-mono text-slate-600 pointer-events-none">
          NO OVERLAY / RAW SLICE
        </div>
      </div>
    </div>
  );
};
